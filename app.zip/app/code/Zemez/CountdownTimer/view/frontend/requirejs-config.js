
var config = {

	map: {
        '*': {
            "countdowntimer": "Zemez_CountdownTimer/js/countdowntimer",
            "jquery.countdown": "Zemez_CountdownTimer/js/jquery.countdown"
        }
    },
    "shim" : {
        "jquery.countdown": ["jquery"]
    }};