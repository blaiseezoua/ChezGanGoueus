
var config = {
    map: {
        '*': {}
    },
    paths: {
        "blogCarousel":           "Zemez_Blog/js/blog-carousel",
        "categoriesListCollapse": "Zemez_Blog/js/categories-list-collapse",
        "blogOwlCarousel":        "Zemez_Blog/js/owl.carousel"
    },
    shim: {
        "blogOwlCarousel":  ["jquery"]
    }
};

