<?php

namespace Zemez\Blog\Controller\Adminhtml\Post;

class RelatedProductsGrid extends RelatedProducts
{
}
