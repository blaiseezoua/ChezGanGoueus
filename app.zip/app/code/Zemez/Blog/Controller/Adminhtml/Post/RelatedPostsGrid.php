<?php

namespace Zemez\Blog\Controller\Adminhtml\Post;

class RelatedPostsGrid extends RelatedPosts
{
}
