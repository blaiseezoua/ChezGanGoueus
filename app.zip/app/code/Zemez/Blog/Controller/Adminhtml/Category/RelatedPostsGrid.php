<?php

namespace Zemez\Blog\Controller\Adminhtml\Category;

class RelatedPostsGrid extends RelatedPosts
{
}
