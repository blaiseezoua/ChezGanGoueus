var config = {
    map: {
        '*': {
             "compareItems" : "Zemez_AjaxCompare/js/tm-compare-ajax",
             "showCompareProduct" : "Zemez_AjaxCompare/js/compare-products-top-link",
        }
    }
};
