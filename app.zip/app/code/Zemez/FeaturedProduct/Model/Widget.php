<?php
/**
 * Created by PhpStorm.
 * User: impro
 * Date: 07/03/17
 * Time: 13:45
 */

namespace Zemez\FeaturedProduct\Model;

use \Magento\Widget\Model\Widget as BaseWidget;

class Widget
{
    public function beforeGetWidgetDeclaration(BaseWidget $subject, $type, $params = [], $asIs = true)
    {

    }
}