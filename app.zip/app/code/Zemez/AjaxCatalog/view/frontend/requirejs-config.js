var config = {
    map: {
        '*': {
            productListToolbarForm : 'Zemez_AjaxCatalog/js/tm-catalog-ajax'
        }
    },
    paths: {
        priceRangeSlider: 'Zemez_AjaxCatalog/js/tm-price-slider'
    }
};