var config = {
    map: {
        '*': {
            'ajaxWishlist': 'Zemez_AjaxWishlist/js/ajaxwishlist',
            'wishlist': 'Zemez_AjaxWishlist/js/wishlist'
        }
    }
};