var config = {
    map: {
        '*': {
            "quickSearch" : "Zemez_AjaxSearch/js/tm-search-ajax"
        }
    },
};